// background.js

async function getBlockedDomainsFromStorage() {
  const { blockTikTok = false, blockedDomains = [] } =
    await browser.storage.sync.get({
      blockTikTok: false,
      blockedDomains: []
    });
  return { blockTikTok, blockedDomains };
}

function handleRedirect(requestDetails) {
  const url = new URL(requestDetails.url);
  const { blockTikTok, blockedDomains } = this;

  if (blockTikTok && url.hostname.includes('tiktok.com')) {
    return { redirectUrl: browser.runtime.getURL("blocked.html") };
  }

  for (const dom of blockedDomains) {
    if (url.hostname.includes(dom)) {
      return { redirectUrl: browser.runtime.getURL("blocked.html") };
    }
  }

  return {};
}

async function updateBlockingRules() {
  if (browser.webRequest.onBeforeRequest.hasListener(handleRedirect)) {
    browser.webRequest.onBeforeRequest.removeListener(handleRedirect);
  }

  const { blockTikTok, blockedDomains } = await getBlockedDomainsFromStorage();
  const urlsToBlock = [];
  if (blockTikTok) {
    urlsToBlock.push("*://*.tiktok.com/*");
  }
  for (const dom of blockedDomains) {
    urlsToBlock.push(`*://*.${dom}/*`);
  }

  if (urlsToBlock.length > 0) {
    browser.webRequest.onBeforeRequest.addListener(
      handleRedirect.bind({ blockTikTok, blockedDomains }),
      { urls: urlsToBlock, types: ["main_frame"] },
      ["blocking"]
    );
  }
}

browser.runtime.onInstalled.addListener(updateBlockingRules);
browser.runtime.onMessage.addListener((msg, _s, sendResponse) => {
  if (msg.type === 'updateRules') {
    updateBlockingRules().then(() => sendResponse());
    return true;
  }
});