// background.js

let currentPatterns = [];
let listener = null;

function updateBlockingListeners() {
  chrome.storage.sync.get({
    blockTikTok: false,
    filterYtShorts: false,
    blockedDomains: []
  }, ({ blockTikTok, filterYtShorts, blockedDomains }) => {
    // Construire la liste des patterns à bloquer
    const patterns = [];

    if (blockTikTok) {
      patterns.push("*://*.tiktok.com/*");
    }
    if (filterYtShorts) {
      patterns.push("*://*.youtube.com/shorts/*");
    }
    for (const dom of blockedDomains) {
      // on bloque le domaine et tous ses sous-domaines
      patterns.push(`*://${dom}/*`);
      patterns.push(`*://*.${dom}/*`);
    }

    // Retirer l'ancien listener si existant
    if (listener) {
      chrome.webRequest.onBeforeRequest.removeListener(listener);
      listener = null;
    }

    // Installer le nouveau
    if (patterns.length) {
      listener = details => ({
        redirectUrl: chrome.runtime.getURL("blocked.html")
      });
      chrome.webRequest.onBeforeRequest.addListener(
        listener,
        { urls: patterns, types: ["main_frame"] },
        ["blocking"]
      );
      currentPatterns = patterns;
    }
  });
}

// Au chargement et après chaque modif des prefs
chrome.runtime.onInstalled.addListener(updateBlockingListeners);
chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
  if (msg.type === "updateRules") {
    updateBlockingListeners();
    sendResponse();
  }
});
